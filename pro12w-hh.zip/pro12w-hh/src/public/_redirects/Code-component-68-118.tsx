# Netlify redirects for React Router
/*    /index.html   200

# Handle static files
/robots.txt   /robots.txt   200
/sitemap.xml  /sitemap.xml  200

# Handle direct page access
/home         /index.html   200
/pricing      /index.html   200
/channels     /index.html   200
/about        /index.html   200
/faq          /index.html   200
/contact      /index.html   200
/blog         /index.html   200
/testimonials /index.html   200
/support      /index.html   200
/terms        /index.html   200
/privacy      /index.html   200
/refund       /index.html   200
/checkout     /index.html   200