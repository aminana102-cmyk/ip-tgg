
  # Multi-Page Website Design

  This is a code bundle for Multi-Page Website Design. The original project is available at https://www.figma.com/design/hoHw7RSe66d6Ngv5oNEI9n/Multi-Page-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  